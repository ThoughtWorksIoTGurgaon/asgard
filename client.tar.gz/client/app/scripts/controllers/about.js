'use strict';

/**
 * @ngdoc function
 * @name cloudStoreClient
 * @description
 * # AboutCtrl
 * Controller of the cloudStoreClient
 */
angular.module('cloudStoreClient')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
